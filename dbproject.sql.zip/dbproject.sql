-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 16, 2019 at 05:47 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(10) NOT NULL,
  `last_name` varchar(10) NOT NULL,
  `email` varchar(25) NOT NULL,
  `pass` varchar(15) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `accounts`
--

TRUNCATE TABLE `accounts`;
--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`account_id`, `first_name`, `last_name`, `email`, `pass`) VALUES
(27, 'Salman', 'Hanif', 'salmanhanif133@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
CREATE TABLE IF NOT EXISTS `activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `appliance_id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `turnOn_time` timestamp NULL DEFAULT NULL,
  `turnOff_time` timestamp NULL DEFAULT NULL,
  `current_state` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`activity_id`),
  KEY `appliance_id` (`appliance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=270 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `activity`
--

TRUNCATE TABLE `activity`;
--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`activity_id`, `appliance_id`, `device_id`, `turnOn_time`, `turnOff_time`, `current_state`) VALUES
(244, 26, 2665, '2019-11-16 16:05:24', NULL, 'online'),
(245, 26, 2665, NULL, '2019-11-16 16:05:58', 'offline'),
(246, 26, 2665, NULL, '2019-11-16 16:06:09', 'offline'),
(247, 26, 2665, '2019-11-16 16:06:18', NULL, 'online'),
(248, 26, 2665, NULL, '2019-11-16 16:06:27', 'offline'),
(249, 26, 2665, '2019-11-16 16:06:41', NULL, 'online'),
(250, 26, 2665, NULL, '2019-11-16 16:06:51', 'offline'),
(251, 26, 2665, '2019-11-16 16:07:56', NULL, 'online'),
(252, 26, 2665, NULL, '2019-11-16 16:10:12', 'offline'),
(253, 26, 2665, '2019-11-16 16:11:03', NULL, 'online'),
(254, 26, 2665, NULL, '2019-11-16 16:11:10', 'offline'),
(255, 26, 2665, '2019-11-16 16:12:06', NULL, 'online'),
(256, 26, 2665, NULL, '2019-11-16 16:19:01', 'offline'),
(257, 26, 2665, '2019-11-16 16:19:04', NULL, 'online'),
(258, 26, 2665, NULL, '2019-11-16 16:20:15', 'offline'),
(259, 26, 2665, '2019-11-16 16:21:06', NULL, 'online'),
(260, 26, 2665, NULL, '2019-11-16 16:21:19', 'offline'),
(261, 26, 2665, '2019-11-16 16:26:49', NULL, 'online'),
(262, 26, 2665, NULL, '2019-11-16 16:26:53', 'offline'),
(263, 26, 2665, '2019-11-16 16:27:05', NULL, 'online'),
(264, 26, 2665, NULL, '2019-11-16 16:27:07', 'offline'),
(265, 26, 2665, '2019-11-16 16:27:14', NULL, 'online'),
(266, 26, 2665, NULL, '2019-11-16 16:27:15', 'offline'),
(267, 26, 2665, '2019-11-16 16:28:24', NULL, 'online'),
(268, 26, 2665, NULL, '2019-11-16 16:28:26', 'offline'),
(269, 26, 2665, '2019-11-16 16:28:26', NULL, 'online');

-- --------------------------------------------------------

--
-- Table structure for table `appliances`
--

DROP TABLE IF EXISTS `appliances`;
CREATE TABLE IF NOT EXISTS `appliances` (
  `appliance_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `appliance_name` varchar(50) NOT NULL,
  `rating` int(11) NOT NULL,
  `is_on` varchar(4) DEFAULT NULL,
  `add_time` timestamp NULL DEFAULT NULL,
  `auto_off_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`appliance_id`),
  KEY `room_id` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `appliances`
--

TRUNCATE TABLE `appliances`;
--
-- Dumping data for table `appliances`
--

INSERT INTO `appliances` (`appliance_id`, `room_id`, `appliance_name`, `rating`, `is_on`, `add_time`, `auto_off_time`) VALUES
(26, 271, 'bulb', 10, 'on', '2019-11-16 16:05:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `daily_report`
--

DROP TABLE IF EXISTS `daily_report`;
CREATE TABLE IF NOT EXISTS `daily_report` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `house_id` int(11) DEFAULT NULL,
  `total_consumption` float DEFAULT NULL,
  `electricity_wasted` float DEFAULT NULL,
  `saved` float DEFAULT NULL,
  PRIMARY KEY (`report_id`),
  KEY `house_id` (`house_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `daily_report`
--

TRUNCATE TABLE `daily_report`;
--
-- Dumping data for table `daily_report`
--

INSERT INTO `daily_report` (`report_id`, `house_id`, `total_consumption`, `electricity_wasted`, `saved`) VALUES
(4, 27, 39.8334, 19.6667, 9.33333);

-- --------------------------------------------------------

--
-- Table structure for table `electricity`
--

DROP TABLE IF EXISTS `electricity`;
CREATE TABLE IF NOT EXISTS `electricity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appliance_id` int(11) NOT NULL,
  `current_consumption` float NOT NULL,
  `previous_consumption` float NOT NULL,
  `wastage` float NOT NULL,
  `temp` float NOT NULL,
  `temp_waste` float DEFAULT '0',
  `saved` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appliance_id` (`appliance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `electricity`
--

TRUNCATE TABLE `electricity`;
--
-- Dumping data for table `electricity`
--

INSERT INTO `electricity` (`id`, `appliance_id`, `current_consumption`, `previous_consumption`, `wastage`, `temp`, `temp_waste`, `saved`) VALUES
(19, 26, 21.8334, 0, 80, 20.1667, 0, 11.5);

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

DROP TABLE IF EXISTS `houses`;
CREATE TABLE IF NOT EXISTS `houses` (
  `house_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `house_name` varchar(20) DEFAULT NULL,
  `owner_name` varchar(50) NOT NULL,
  `rooms` int(11) NOT NULL,
  PRIMARY KEY (`house_id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `houses`
--

TRUNCATE TABLE `houses`;
--
-- Dumping data for table `houses`
--

INSERT INTO `houses` (`house_id`, `account_id`, `house_name`, `owner_name`, `rooms`) VALUES
(27, 27, '', 'Salman Hanif', 4);

-- --------------------------------------------------------

--
-- Table structure for table `monthly_report`
--

DROP TABLE IF EXISTS `monthly_report`;
CREATE TABLE IF NOT EXISTS `monthly_report` (
  `report_id` int(11) NOT NULL,
  `house_id` int(11) DEFAULT NULL,
  `total_consumption` varchar(10) DEFAULT NULL,
  `electricity_consumption` varchar(10) DEFAULT NULL,
  `electricity_wasted` varchar(10) DEFAULT NULL,
  `saved` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`report_id`),
  KEY `house_id` (`house_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `monthly_report`
--

TRUNCATE TABLE `monthly_report`;
-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
CREATE TABLE IF NOT EXISTS `rooms` (
  `room_id` int(11) NOT NULL,
  `house_id` int(11) NOT NULL,
  `room_name` varchar(20) DEFAULT NULL,
  `appliances` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `motion_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`room_id`),
  KEY `house_id` (`house_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `rooms`
--

TRUNCATE TABLE `rooms`;
--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_id`, `house_id`, `room_name`, `appliances`, `count`, `motion_time`) VALUES
(271, 27, 'living room', 1, 1, '2019-11-16 16:19:15');

-- --------------------------------------------------------

--
-- Table structure for table `rooms_report`
--

DROP TABLE IF EXISTS `rooms_report`;
CREATE TABLE IF NOT EXISTS `rooms_report` (
  `report_id` int(11) NOT NULL,
  `house_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `total_consumption` varchar(10) DEFAULT NULL,
  `electricity_consumption` varchar(10) DEFAULT NULL,
  `electricity_wasted` varchar(10) DEFAULT NULL,
  `saved` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`report_id`),
  KEY `house_id` (`house_id`),
  KEY `room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `rooms_report`
--

TRUNCATE TABLE `rooms_report`;
-- --------------------------------------------------------

--
-- Table structure for table `rooms_sensor`
--

DROP TABLE IF EXISTS `rooms_sensor`;
CREATE TABLE IF NOT EXISTS `rooms_sensor` (
  `room_id` int(11) NOT NULL,
  `sensor_id` int(11) NOT NULL,
  PRIMARY KEY (`room_id`,`sensor_id`) USING BTREE,
  KEY `room_id` (`room_id`),
  KEY `sensor_id` (`sensor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `rooms_sensor`
--

TRUNCATE TABLE `rooms_sensor`;
--
-- Dumping data for table `rooms_sensor`
--

INSERT INTO `rooms_sensor` (`room_id`, `sensor_id`) VALUES
(271, 2062),
(271, 2665);

-- --------------------------------------------------------

--
-- Table structure for table `sensors`
--

DROP TABLE IF EXISTS `sensors`;
CREATE TABLE IF NOT EXISTS `sensors` (
  `sensor_id` int(11) NOT NULL,
  `sensor_name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`sensor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `sensors`
--

TRUNCATE TABLE `sensors`;
--
-- Dumping data for table `sensors`
--

INSERT INTO `sensors` (`sensor_id`, `sensor_name`, `type`) VALUES
(2062, 'Motion Sensor', 'Motion Sensor'),
(2665, 'Appliance Sensor', 'Appliance Sensor');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity`
--
ALTER TABLE `activity`
  ADD CONSTRAINT `activity_ibfk_1` FOREIGN KEY (`appliance_id`) REFERENCES `appliances` (`appliance_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `appliances`
--
ALTER TABLE `appliances`
  ADD CONSTRAINT `appliances_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `electricity`
--
ALTER TABLE `electricity`
  ADD CONSTRAINT `electricity_ibfk_1` FOREIGN KEY (`appliance_id`) REFERENCES `appliances` (`appliance_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `houses`
--
ALTER TABLE `houses`
  ADD CONSTRAINT `houses_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `rooms_ibfk_1` FOREIGN KEY (`house_id`) REFERENCES `houses` (`house_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rooms_sensor`
--
ALTER TABLE `rooms_sensor`
  ADD CONSTRAINT `rooms_sensor_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rooms_sensor_ibfk_2` FOREIGN KEY (`sensor_id`) REFERENCES `sensors` (`sensor_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
